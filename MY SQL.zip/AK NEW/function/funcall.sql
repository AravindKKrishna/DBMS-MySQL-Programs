declare
c number(2);
begin
c:=totalcustomer();
dbms_output.put_line('total no of customer is:'||c);
end;
/