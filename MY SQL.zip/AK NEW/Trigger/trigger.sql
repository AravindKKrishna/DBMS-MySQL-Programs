create or replace trigger display_salary_changes BEFORE DELETE OR INSERT OR UPDATE ON customer for each row
when(New.id>0)
declare
sal_diff number;
begin
sal_diff:=:NEW.salary-:OLD.salary;
dbms_output.put_line('OLD salary'||:OLD.salary);
dbms_output.put_line('NEW salary'||:NEW.salary);
dbms_output.put_line('salary difference'||sal_diff);
end;
/