declare
c_id customer.id%type;
c_name customer.name%type;
c_address customer.address%type;
cursor c_customer is 
select id,name,address from customer;
begin
open c_customer;
loop
fetch c_customer into c_id,c_name,c_address;
exit when c_customer%notfound;
dbms_output.put_line(c_id||' '||c_name||' '||c_address);
end loop;
close c_customer;
end;
/