create or replace package cust_sal as 
procedure find_sal(c_id customer.id%type);
end cust_sal;
/