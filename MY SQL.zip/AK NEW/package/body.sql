create or replace package body cust_sal as
procedure find_sal(c_id customer.id%type)is
c_sal customer.salary%type;
begin
select salary into c_sal from
customer where id=c_id;
dbms_output.put_line('salary:'||c_sal);
end find_sal;
end cust_sal;
/