declare
code customer.id%type:=&cc_id;
begin
cust_sal.find_sal(code);
end;
/