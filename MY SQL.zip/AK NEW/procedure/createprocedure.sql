create or replace procedure insertcust
(id IN number,name IN varchar) is
begin
insert into customers values(id,name);
end;
/



