begin
insertcust(1,'Anu');
insertcust(2,'Minu');
insertcust(3,'Vinu');
insertcust(4,'Manu');
insertcust(5,'Arya');
dbms_output.put_line('record insert sucessfully');
end;
/
